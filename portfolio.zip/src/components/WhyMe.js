import React from 'react';
import { motion } from 'framer-motion';

const features = [
  {
    icon: '🕒',
    title: '24/7 Support',
    desc: 'Always available to iterate, debug, and assist with any development needs. Your project gets the attention it deserves — on your schedule, not mine.',
  },
  {
    icon: '⚡',
    title: 'Fast & Reliable',
    desc: 'Delivering high-performance solutions with speed and precision. Clean architecture and best practices mean fewer bugs and faster ship dates.',
  },
  {
    icon: '🔄',
    title: 'Flexible',
    desc: 'Adapting seamlessly to unique project requirements. From MVPs for startups to enterprise-scale systems — I tailor solutions that fit your vision.',
  },
  {
    icon: '🔒',
    title: 'Security First',
    desc: 'Every application is built with security best practices at its core: input validation, JWT auth, encrypted data, and protection against common vulnerabilities.',
  },
  {
    icon: '📈',
    title: 'Scalable Architecture',
    desc: 'I architect systems that grow with your business — microservices, containerization with Docker, and cloud-native deployments on AWS.',
  },
  {
    icon: '🎯',
    title: 'Results Driven',
    desc: 'Focused on delivering measurable outcomes — not just writing code. I understand business goals and translate them into engineering decisions.',
  },
];

const WhyMe = () => {
  return (
    <section className="why-me" id="why-me">
      <motion.div
        style={{ textAlign: 'center' }}
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">Why Work With Me</span>
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        Why Me?
      </motion.h2>

      <div className="features-grid">
        {features.map((item, index) => (
          <motion.div
            className="feature-card"
            key={index}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.4, delay: index * 0.08 }}
          >
            <span className="feature-icon">{item.icon}</span>
            <h3>{item.title}</h3>
            <p>{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default WhyMe;