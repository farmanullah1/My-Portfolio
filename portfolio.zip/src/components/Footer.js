import React from 'react';
import { FaGithub, FaLinkedin, FaTwitter, FaEnvelope } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer>
      <div className="footer-content">
        <div className="footer-logo highlight">Farmanullah.</div>

        <nav className="footer-links" aria-label="Footer navigation">
          <a href="#about">About</a>
          <a href="#skills">Skills</a>
          <a href="#projects">Projects</a>
          <a href="#experience">Experience</a>
          <a href="#certifications">Certifications</a>
          <a href="#contact">Contact</a>
        </nav>

        <div className="footer-social">
          <a href="https://github.com/farmanullah1" target="_blank" rel="noreferrer" aria-label="GitHub"><FaGithub /></a>
          <a href="https://www.linkedin.com/in/farmanullah-ansari" target="_blank" rel="noreferrer" aria-label="LinkedIn"><FaLinkedin /></a>
          <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="Twitter"><FaTwitter /></a>
          <a href="mailto:farmanullahansari999@gmail.com" aria-label="Email"><FaEnvelope /></a>
        </div>
      </div>

      <div className="footer-bottom">
        © {new Date().getFullYear()} <span>Farmanullah Ansari</span>. All Rights Reserved.
        Built with ❤️ using React.js
      </div>

      {/* Back to Top */}
      <a href="#home" className="back-to-top" aria-label="Back to top">↑</a>
    </footer>
  );
};

export default Footer;