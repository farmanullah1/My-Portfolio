import React from 'react';
import { motion } from 'framer-motion';
import {
  FaReact, FaNodeJs, FaDocker, FaPython, FaAws,
  FaLinux, FaGithub, FaHtml5, FaCss3Alt, FaDatabase
} from 'react-icons/fa';
import { SiMongodb, SiExpress, SiTailwindcss, SiPostgresql, SiRedis } from 'react-icons/si';
import { TbBrandCSharp } from 'react-icons/tb';
import { BiNetworkChart } from 'react-icons/bi';
import { BsBarChartFill } from 'react-icons/bs';

const marqueeSkills = [
  { name: 'C#', icon: <TbBrandCSharp /> },
  { name: 'ASP.NET Core', icon: <BiNetworkChart /> },
  { name: 'React.js', icon: <FaReact /> },
  { name: 'Node.js', icon: <FaNodeJs /> },
  { name: 'MongoDB', icon: <SiMongodb /> },
  { name: 'Docker', icon: <FaDocker /> },
  { name: 'AWS', icon: <FaAws /> },
  { name: 'Python', icon: <FaPython /> },
  { name: 'Linux', icon: <FaLinux /> },
  { name: 'Power BI', icon: <BsBarChartFill /> },
  { name: 'Git & GitHub', icon: <FaGithub /> },
  { name: 'PostgreSQL', icon: <SiPostgresql /> },
];

const skillCategories = [
  {
    label: '🌐 Frontend',
    skills: [
      { name: 'React.js', icon: <FaReact /> },
      { name: 'HTML5', icon: <FaHtml5 /> },
      { name: 'CSS3', icon: <FaCss3Alt /> },
      { name: 'Tailwind CSS', icon: <SiTailwindcss /> },
      { name: 'Bootstrap', icon: <FaCss3Alt /> },
    ],
  },
  {
    label: '⚙️ Backend',
    skills: [
      { name: 'C# / ASP.NET Core', icon: <TbBrandCSharp /> },
      { name: 'Node.js', icon: <FaNodeJs /> },
      { name: 'Express.js', icon: <SiExpress /> },
      { name: 'REST APIs', icon: <BiNetworkChart /> },
    ],
  },
  {
    label: '🗄️ Databases',
    skills: [
      { name: 'MongoDB', icon: <SiMongodb /> },
      { name: 'PostgreSQL', icon: <SiPostgresql /> },
      { name: 'SQL Server', icon: <FaDatabase /> },
      { name: 'Redis', icon: <SiRedis /> },
    ],
  },
  {
    label: '☁️ Cloud & DevOps',
    skills: [
      { name: 'AWS (EC2, EB)', icon: <FaAws /> },
      { name: 'Docker', icon: <FaDocker /> },
      { name: 'Linux / Bash', icon: <FaLinux /> },
      { name: 'Git & GitHub', icon: <FaGithub /> },
    ],
  },
  {
    label: '📊 Tools & Other',
    skills: [
      { name: 'Power BI', icon: <BsBarChartFill /> },
      { name: 'Python', icon: <FaPython /> },
    ],
  },
];

const Skills = () => {
  return (
    <section className="skills" id="skills">
      <motion.div
        style={{ textAlign: 'center' }}
        initial={{ opacity: 0, y: -10 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="section-tag">What I Work With</span>
      </motion.div>

      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        Technical Skills
      </motion.h2>

      {/* Marquee */}
      <motion.div
        className="marquee-container"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <div className="marquee-track">
          {[...marqueeSkills, ...marqueeSkills].map((skill, index) => (
            <div key={index} className="skill-card-scroll">
              <div className="skill-icon-large">{skill.icon}</div>
              <p className="skill-name">{skill.name}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Categorized Pills */}
      <motion.div
        className="skills-grid-section"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        {skillCategories.map((cat, ci) => (
          <motion.div
            className="skills-category"
            key={ci}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: ci * 0.08 }}
          >
            <h3>{cat.label}</h3>
            <div className="skills-pills">
              {cat.skills.map((skill, si) => (
                <div className="skill-pill" key={si}>
                  <span className="pill-icon">{skill.icon}</span>
                  {skill.name}
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
};

export default Skills;