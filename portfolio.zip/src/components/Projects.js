import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaExternalLinkAlt, FaGithub, FaPlay } from 'react-icons/fa';

const projectList = [
  {
    title: '🤝 Gadd Kaam — SkillSwap Pakistan',
    desc: 'A comprehensive, secure platform for cashless skill exchanging across Pakistan, featuring CNIC verification, real-time trading, and a dedicated safe zone for women.',
    tech: ['MongoDB', 'Express.js', 'React.js', 'Node.js'],
    live: '',
    code: 'https://github.com/farmanullah1/Gadd-Kaam-SkillSwap-Pakistan',
    watch: '',
    featured: true,
  },
  {
    title: '📰 Kurrent News',
    desc: 'A real-time global news SPA featuring a Triple-API fallback architecture to ensure 100% deployment uptime, infinite scrolling, and dark mode.',
    tech: ['React.js', 'NewsAPI', 'Bootstrap'],
    live: 'https://farmanullah1.github.io/Kurrent-News-Top-Headlines-Tech-Politics-Sports/',
    code: 'https://github.com/farmanullah1/Kurrent-News-Top-Headlines-Tech-Politics-Sports',
    watch: '',
  },
  {
    title: '🛠️ TextUtils Studio',
    desc: 'A premium browser-based text manipulation and analytics toolkit with a "Deep Cyber Glass" UI. Offers 100+ advanced formatting, extraction, and cryptography tools.',
    tech: ['React.js', 'Bootstrap'],
    live: 'https://farmanullah1.github.io/TextUtils-React.js/',
    code: 'https://github.com/farmanullah1/TextUtils-React.js',
    watch: '',
  },
  {
    title: '⚙️ ASP.NET Core Web API',
    desc: 'A robust backend REST API demonstrating efficient CRUD operations, built with modern C# and ASP.NET Core best practices.',
    tech: ['C#', 'ASP.NET Core', 'Web API'],
    live: '',
    code: 'https://github.com/farmanullah1/CRUD-App-Using-ASP-Core-Web-API',
    watch: '',
  },
  {
    title: '✊ Stone, Paper, Scissors',
    desc: 'An interactive browser-based game featuring dynamic UI updates and classic game logic.',
    tech: ['HTML', 'CSS', 'JavaScript'],
    live: 'https://farmanullah1.github.io/Stone-Paper-Scissors-Game-HTML-CSS-JS/',
    code: 'https://github.com/farmanullah1/Stone-Paper-Scissors-Game-HTML-CSS-JS',
    watch: '',
  },
  {
    title: '❌⭕ Tic-Tac-Toe',
    desc: 'A classic Tic-Tac-Toe web game with responsive design and state management for turn-based gameplay.',
    tech: ['HTML', 'CSS', 'JavaScript'],
    live: 'https://farmanullah1.github.io/Tic-Tac-Toe-HTML-CSS-JS/',
    code: 'https://github.com/farmanullah1/Tic-Tac-Toe-HTML-CSS-JS',
    watch: '',
  },
];

const FILTERS = ['All', 'React.js', 'Node.js', '.NET', 'Python', 'Web Basics'];

const Projects = () => {
  const [filter, setFilter] = useState('All');

  const filteredProjects = projectList.filter((proj) => {
    if (filter === 'All') return true;
    if (filter === '.NET') return proj.tech.includes('C#') || proj.tech.includes('ASP.NET Core');
    if (filter === 'Web Basics') return proj.tech.includes('HTML');
    return proj.tech.includes(filter);
  });

  return (
    <section className="projects" id="projects">
      <motion.div style={{ textAlign: 'center' }} initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
        <span className="section-tag">What I've Built</span>
      </motion.div>

      <motion.h2 initial={{ opacity: 0, y: -20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
        Featured Projects
      </motion.h2>

      <div className="filter-container">
        {FILTERS.map((category) => (
          <button
            key={category}
            className={`filter-btn ${filter === category ? 'active' : ''}`}
            onClick={() => setFilter(category)}
          >
            {category}
          </button>
        ))}
      </div>

      <motion.div layout className="project-grid">
        <AnimatePresence mode="popLayout">
          {filteredProjects.map((proj) => (
            <motion.div
              className="project-card"
              key={proj.title}
              layout
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.88, y: -10 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
            >
              {proj.featured && (
                <span style={{
                  display: 'inline-block',
                  fontSize: '0.72rem',
                  fontWeight: 700,
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: '#fbbf24',
                  background: 'rgba(251,191,36,0.1)',
                  border: '1px solid rgba(251,191,36,0.25)',
                  padding: '4px 12px',
                  borderRadius: '20px',
                  marginBottom: '14px',
                }}>
                  ⭐ Final Year Project
                </span>
              )}
              <h3>{proj.title}</h3>
              <p>{proj.desc}</p>
              <div className="tech-stack">
                {proj.tech.map((t, i) => <span key={i}>{t}</span>)}
              </div>
              <div className="project-links">
                {proj.live && (
                  <a href={proj.live} target="_blank" rel="noreferrer" className="btn-secondary">
                    <FaExternalLinkAlt style={{ marginRight: 6 }} />Live Demo
                  </a>
                )}
                {proj.watch && (
                  <a href={proj.watch} target="_blank" rel="noreferrer" className="btn-secondary">
                    <FaPlay style={{ marginRight: 6 }} />Watch Online
                  </a>
                )}
                {proj.code && (
                  <a href={proj.code} target="_blank" rel="noreferrer" className="btn-secondary">
                    <FaGithub style={{ marginRight: 6 }} />View Code
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </section>
  );
};

export default Projects;